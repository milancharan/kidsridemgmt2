import React, { useState } from 'react'


export default function TimeSlot({ride, selects, setSelects}) {
  const [select, setSelect] = useState([])

  const manageSelect = (e) => {
    console.log(typeof(e.target.name));
    let val = ''+ e.target.value
    setSelect([...select, val])
    setSelects([...selects, val])
    // console.log(typeof(val));
  }

  return (
    <div>
        <label>TimeSlot: <select onChange={manageSelect}>
            <option disabled selected>--Select--</option>
            <option value={ride.TimeSlot[0]} name={1}>{ride.TimeSlot[0]}</option>
            <option disabled></option>
            <option value={ride.TimeSlot[1]} name={2}>{ride.TimeSlot[1]}</option>
            <option disabled></option>
            <option value={ride.TimeSlot[2]} name={3}>{ride.TimeSlot[2]}</option>
        </select></label>
    </div>
  )
}
