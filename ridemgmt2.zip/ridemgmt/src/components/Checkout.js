import React, { useEffect, useState } from 'react'
import OrderPlaced from './OrderPlaced';
import TimeSlot from './TimeSlot';
import { logDOM } from '@testing-library/react';

export default function Checkout({ ride, setCart, cart}) {
    const [otp, setOtp] = useState(0)
    const [selected, setSelected] = useState([])
    const countTotal = () => {
        let amount = 0
        cart.forEach((ride) => {
            amount += parseInt(ride.Amount)
        });
        return amount
    }

    
    const manageOtp = () => {
        let otp1 = Math.floor(1000 + Math.random() * 9000)
        const regex = new RegExp('^[0-9]{4}$')
        if(regex.test(otp1)){
            setOtp(otp1)
        }
        // console.log([...selected]);
        // console.log(selected.length);
        // console.log(cart.length);
    }
    
    useEffect(()=>{
        setCart([])
    },[otp])

    
    const manageRemoveFromcart = (e) => {
            // console.log(e.target.value);
            // console.log(cart.length);
            // console.log(selected.length);
        let temp = [...cart]
        temp.splice(e.target.value, 1)
        setCart(temp)
        // let temp1 = [...selected]
        // temp.splice(e.target.value, 1)
        // setSelected(temp1)
        // let temp = cart
        // setCart((current) => current.filter((cart)=>cart.id===cart.id))
    }
    
    const validateCart = () => {
        console.log([...cart]);
        return (cart.length === selected.length) && (cart.length && selected.length)
    }
    return (
        <div>
            <h3 className='text-center'>Checkout Here</h3>
            <div className='content-checkout'>
                {cart.map((ride, i) => (
                    <div className='border border-dark rounded text-center content-item-checkout'>
                        <img src={ride.RideImage} width={40} height={45} alt={ride.RideName} />
                        <h3 className='mt-4'>{ride.RideName}</h3>
                        <p>Amount: {ride.Amount}</p>
                        <TimeSlot ride={ride} selects={selected} setSelects={setSelected} />
                        <button type='button' value={i} onClick={manageRemoveFromcart}>Remove</button>
                    </div>
                ))}
            </div>
            <div className='text-center justify-content-between'>
                <h3>Total To Pay: {countTotal()}</h3><button type='button' className='btn' onClick={manageOtp} disabled={!validateCart()}>Proceed To Pay</button>
            </div>

            {otp ? <OrderPlaced setOtp={setOtp} setCarts={setCart} setSelected={setSelected}/> : null}
        </div>
    )
}
