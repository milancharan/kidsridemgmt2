import React, { useState } from 'react'


export default function TimeSlot({ride}) {
  const [select, setSelect] = useState([])

  const manageSelect = (e) => {
    setSelect(e.target.value)
    console.log(e.target.value);
  }

  return (
    <div>
        <label>TimeSlot: <select onChange={manageSelect}>
            <option>--Select--</option>
            <option value={ride.TimeSlot[0]}>{ride.TimeSlot[0]}</option>
            <option></option>
            <option value={ride.TimeSlot[1]}>{ride.TimeSlot[1]}</option>
            <option></option>
            <option value={ride.TimeSlot[2]}>{ride.TimeSlot[2]}</option>
        </select></label>
    </div>
  )
}
